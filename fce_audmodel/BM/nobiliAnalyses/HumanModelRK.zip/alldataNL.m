function [x,Gs,G,M,stiff,ShSp,undamp,bigamma,wm2] = alldataNL(N,Fo,alpha,base);
%
% 	Function ALLDATANL is called by the main routine in order to load 
%   all data being necessary to the frequency domain implementation of the human cochlea
%    
%	 x  =	BM point vector (nonuniform (function vargrid1(N))
%    Gs =	Stapes propagator multiplayed by the inverse of the Green's function
%	 G =	  the Green's function
%	 DampSp = BM damping matrix accounting for absolute and shear viscosity
%	 stiff = BM stiffness vector
%	 undamp = undamping vector
%	 wm2 =	TM normalized stiffness (K/M)
%	 bigamma =	TM normalized damping   (H/M)
if nargin<4, base=2.2022;    end
if nargin<3, alpha=-7.3094;  end
if nargin<2, Fo=2.0899e+004; end 
if nargin<1  N=600;          end

%________________________BM data_______________________________
if exist('BMDATANL.MAT')==2,
	load BMDATANL.MAT
else,
	x = gaussgrid(N);  % Generates a set of points covering the interval 0-1 with Gaussian distributed density    (see GAUSSGRID.M) 
    bmdataNL(x); 
    load BMDATANL.MAT
end

%________________________________________________
 load LAMBDAS6a.MAT lam

 %--------------------TM-parameters-----------
 %-------------------------------------------
  wm=2*pi*Fo*base.^(alpha*(x+0.05));
  wm2=wm.*wm;  % equivalent to K/M along the TM 
  bigamma=2*pi*Fo*base.^(0.5*alpha*(x+0.05));
  bigamma=bigamma(:)./0.95;
  wm2=wm2(:);% equivalent to H/M along the TM 
  undamp=0.87*damp0.*bigamma.*lam;
  undamp=undamp(:);
  stiff=stiff(:);


